// This file contains the JavaScript logic for the popup. It handles user interactions and initializes the game when the popup is opened.

document.addEventListener('DOMContentLoaded', function() {
    const startButton = document.getElementById('start-game');
    const gameContainer = document.getElementById('game-container');

    startButton.addEventListener('click', function() {
        initializeGame();
        gameContainer.style.display = 'block';
    });

    function initializeGame() {
        // Logic to initialize the game goes here
        console.log('Game initialized');
    }
});